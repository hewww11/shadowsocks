# Shadowsocks.exe
翻墙软件
# 翻墙地址
http://www.ishadowsocks.org/
http://freevpnss.cc/#vpn